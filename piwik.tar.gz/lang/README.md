## Contribute

We cannot accept pull requests for translations on Github since we manage all translations in a separate system. Translations will automatically be merged from time to time! If you want to improve an existing Piwik translation, or contribute a new translation, please have a look at our [translation center](http://translations.piwik.org).

If you have any questions feel free to contact the team at translations@piwik.org.
